#!/bin/bash
#LD_PRELOAD=/lib/x86_64-linux-gnu/libpthread.so.0 bochs -f bochs_config
#export GTK_PATH=/usr/lib/x86_64-linux-gnu/gtk-2.0/
	export GTK_PATH=/usr/lib/x86_64-linux-gnu/gtk-3.0/   #For GTK 3 if applicable
bochs -f bochs_config