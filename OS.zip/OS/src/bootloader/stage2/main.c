#include "stdint.h"
#include "stdio.h"
#include "disk.h"
#include "fat.h"
#include "io.h"
#include "terminal.h"


void _cdecl cstart_(uint16_t bootDrive){

    DISK disk;
    if(!DISK_Initialize(&disk, bootDrive))
    {
        printf("Failed To Initialize the drive!\r\n");
        goto end;
    }

    if(!FAT_Initialize(&disk))
    {
        printf("Failed To Initialize FAT!\r\n");
        goto end;
    }

    // browese files in root
    FAT_File far* fd = FAT_Open(&disk, "/");
    FAT_DirectoryEntry entry;
    printf("%i\r\n",fd->Handle);
    int i = 0;
    while (FAT_ReadEntry(&disk, fd, &entry)&& i < 12)
    {
        printf("   ");
        for (int i = 0; i < 11; i++)
        {
            putc(entry.Name[i]);
        }
        printf("\r\n");
        i++;
        
    }
    FAT_Close(fd);

goto end;
    char buffer[100];
    uint32_t read;
    fd = FAT_Open(&disk, "/mydir/bigtext.txt");
    while ((read = FAT_Read(&disk, fd, sizeof(buffer), buffer))&& i < 1200)
    {
        //printf("%lu\r\n", read);
        for (uint32_t i = 0; i < read; i++)
        {
            if(buffer[i] == '\n')
                putc('\r');
            putc(buffer[i]);
        }
        i++;
    }
    FAT_Close(fd);


end:
    printf("Welcome to the Kernel Terminal!\r\n");
    terminal(&disk);

    for (;;);
}



void TestPrintF()
{
    clearScreen();
    //const char far* far_str = "far string";

    puts("Hello World!\r\n");
    //printf("Formatted %% %c %s %ls\r\n", 'a', "string", far_str);
    printf("Formatted %d %i %x %p %o %hd %hi %hhu %hhd\r\n", 1234, -5678, 0xdead, 0xbeef, 012345, (short)27, (short)-42, (unsigned char)20, (signed char)-10);
    printf("Formatted %ld %lx %lld %llx\r\n", -100000000l, 0xdeadbeeful, 10200300400ll, 0xdeadbeeffeebdaedull);
}
