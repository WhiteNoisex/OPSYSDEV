#pragma once

#include "stdint.h"

bool islower(char chr);
bool islower(char chr);
char toupper(char chr);
char tolower(char chr);
