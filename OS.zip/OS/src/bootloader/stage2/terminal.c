#include "stdint.h"
#include "stdio.h"
#include "disk.h"
#include "fat.h"
#include "io.h"
#include "terminal.h"
#include "memory.h"

void terminal(DISK* disk) {
    char c; // Character input buffer
    puts("Custom Kernel Terminal. Type 'exit' to quit.\r\n");

    while (1) {
        puts("KernelTerminal> ");

        char command[256] = {0}; // Initialize the command buffer
        int index = 0;

        while (1) {
            c = getchar();

            if (c == '\r') { // Enter key
                command[index] = '\0'; // Null-terminate the command
                puts("\r\n");           // Move to the next line
                break;
            } else if (c == '\b') { // Backspace
                if (index > 0) {
                    --index;
                    puts("\b \b"); // Erase last character
                }
            } else {
                if (index < 255) {
                    command[index++] = c;
                    putc(c); // Echo character
                }
            }
        }

        // Debug: Print the command for verification
        printf("Command entered: %s\r\n", command);

        // Handle 'listdir' command
        if (index >= 7 && memcmp(command, "listdir", 7) == 0) {
            // browese files in root
            FAT_File far* fd = FAT_Open(disk, "/");
            FAT_DirectoryEntry entry;
            printf("%i\r\n",fd->Handle);
            int i = 0;
            while (FAT_ReadEntry(disk, fd, &entry)&& i < 12)
            {
                printf("   ");
                for (int i = 0; i < 11; i++)
                {
                    putc(entry.Name[i]);
                }
                printf("\r\n");
                i++;
                
            }
            FAT_Close(fd);
            //break;
        } else if (index >= 4 && memcmp(command, "exit", 4) == 0) {
            puts("Exiting terminal...\r\n");
            break;
        } else {
            puts("Command not recognized: ");
            puts(command);
            puts("\r\n");
        }
    }
}
