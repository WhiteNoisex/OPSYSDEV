#include "string.h"
#include "stdint.h"



const char* strchr(const char* str, char chr)
{
    if(str == NULL)
        return NULL;
    
    while (*str)
    {
        if(*str == chr)
            return str;

        ++str;
    }

    return NULL;
}

const char* strchr_last(const char* str, char chr)
{
    if(str == NULL)
        return NULL;

    const char* last_occerance = NULL;
    
    while (*str)
    {
        if(*str == chr)
            last_occerance = str;

        ++str;
    }

    return last_occerance;
}

char* strcpy(char* dst, const char* src)
{
    char* origDst = dst;

    if(src == NULL)
    {
        *dst = '\0';
        return NULL;
    }

    if(dst == NULL)
        return NULL;
    
    while (*src)
    {
        *dst = *src;
        ++dst;
        ++src;
    }

    *dst = '\0';
    return origDst;
}

unsigned strlen(const char* str)
{
    unsigned len = 0;
    while (*str)
    {
        ++len;
        ++str;
    }
    return len;
}
