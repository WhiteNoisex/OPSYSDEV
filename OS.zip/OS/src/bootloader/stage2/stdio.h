#pragma once

void putc(char c);
void puts(const char* str);
void _cdecl printf(const char* fmt, ...);
void _cdecl clearScreen();
