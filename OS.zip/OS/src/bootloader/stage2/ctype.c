#include "ctype.h"

bool isupper(char chr)
{
    return chr >= 'A' && chr <= 'Z';
}
bool islower(char chr)
{
    return chr >= 'a' && chr <= 'z';
}

char toupper(char chr)
{
    return islower(chr) ? (chr - 'a' + 'A') : chr;
}
char tolower(char chr)
{
    return islower(chr) ? (chr - 'A' + 'a') : chr;
}
