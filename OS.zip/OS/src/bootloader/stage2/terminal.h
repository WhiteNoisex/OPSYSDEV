#pragma once
#include "stdio.h"

void terminal(DISK* disk);
