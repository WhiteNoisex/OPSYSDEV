#include "stdint.h"    // For uint8_t, uint32_t, etc.
#include "fat.h" // Include FAT structures and functions

void read_file_to_console(DISK* disk, const char* file_path);
void read_file_to_console_binary(DISK* disk, const char* file_path);
void print_byte_in_binary(uint8_t byte);
void printfolder(DISK* disk, const char* folder_path);
char getchar();
