#include "stdio.h" // For printf and putc
#include "io.h"
#include "fat.h"
#include "x86.h"

void printfolder(DISK* disk, const char* folder_path) {
    FAT_File far* fd = FAT_Open(disk, folder_path);
    if (fd == NULL) {
        printf("FAT: Could not open directory: %s\r\n", folder_path);
        return;
    }

    FAT_DirectoryEntry entry;
    printf("Printing Folder Contents from: %s\r\n", folder_path);

    while (FAT_ReadEntry(disk, fd, &entry)) {
        // Check if entry is a directory or file
        bool is_directory = (entry.Attributes & FAT_ATTRIBUTE_DIRECTORY) != 0;

        // Print entry name
        for (int i = 0; i < 11; i++) {
            putc(entry.Name[i]);
        }
        printf(is_directory ? " [DIR]\r\n" : " [FILE]\r\n");
    }

    FAT_Close(fd);
}

// Function to read a file's contents to the console
void read_file_to_console(DISK* disk, const char* file_path) {
    printf("Opening file: %s\r\n", file_path);

/*
    char buffer[100];
    uint32_t read;
    fd = FAT_Open(&disk, "/mydir/test.txt");
    while ((read = FAT_Read(&disk, fd, sizeof(buffer), buffer)))
    {
        printf("%lu\r\n", read);
        for (uint32_t i = 0; i < read; i++)
        {
            putc(buffer[i]);
        }
        
    }
    FAT_Close(fd);
    
*/

    FAT_File far* file = FAT_Open(disk, file_path);
    if (file == NULL) {
        // File could not be found or opened
        printf("Error: File not found or could not be opened: %s\r\n", file_path);
        return;
    }

    // Buffer to hold chunks of file data
    uint8_t buffer[512];
    uint32_t bytes_read;
    uint32_t total_bytes_read = 0;

    // Read the file in chunks and print each chunk to the console
    while (bytes_read > 0) {
        // Attempt to read up to 512 bytes (or less if at the end of the file)
        bytes_read = FAT_Read(disk, file, sizeof(buffer), buffer);

        // Check if read was successful
        if (bytes_read > 0) {
            // Print the chunk to the console, handling \r\n consistently
            for (uint32_t i = 0; i < bytes_read; i++) {
                char ch = buffer[i];
                // Print only printable characters (for text files) and newline characters
                //if (ch >= 32 || ch == '\n' || ch == '\r') {
                    if (ch == '\n') {
                        // Convert \n to \r\n for proper line breaks
                        putc('\r');
                        putc('\n');
                    } else {
                        putc(ch);
                    }
                //}
            }
            total_bytes_read += bytes_read;
        }
    } 

    // Close the file after reading
    FAT_Close(file);

    // Print a single line break at the end for clarity
    putc('\r');
    putc('\n');

    // Print the summary of bytes read with \r\n at the end
    printf("Read %lu bytes from file: %s\r\n", total_bytes_read, file_path);
}

// Helper function to print a byte in binary format
void print_byte_in_binary(uint8_t byte) {
    for (int i = 7; i >= 0; i--) {
        putc((byte & (1 << i)) ? '1' : '0');
    }
    putc(' ');  // Space between bytes for readability
}

// Function to read a file's contents in binary format to the console
void read_file_to_console_binary(DISK* disk, const char* file_path) {
    FAT_File far* file = FAT_Open(disk, file_path);
    if (file == NULL) {
        printf("Error: File not found or could not be opened: %s\r\n", file_path);
        return;
    }

    uint8_t buffer[512];
    uint32_t bytes_read;
    uint32_t total_bytes_read = 0;

    do {
        bytes_read = FAT_Read(disk, file, sizeof(buffer), buffer);

        if (bytes_read > 0) {
            for (uint32_t i = 0; i < bytes_read; i++) {
                // Print each byte in binary format
                print_byte_in_binary(buffer[i]);

                // Optional: print a newline every 8 bytes for readability
                if ((i + 1) % 8 == 0) {
                    printf("\r\n");
                }
            }
            total_bytes_read += bytes_read;
        }
    } while (bytes_read > 0);

    FAT_Close(file);

    putc('\r');
    putc('\n');
    printf("Read %lu bytes from file: %s\r\n", total_bytes_read, file_path);
}


char getchar() {
    return x86_getchar();
}