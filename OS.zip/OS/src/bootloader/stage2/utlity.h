#pragma once
#include "stdint.h"

uint32_t align(uint32_t number, uint32_t alignTo);
